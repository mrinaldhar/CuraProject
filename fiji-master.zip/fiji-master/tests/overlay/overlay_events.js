/*
 * overlay_events.js
 */
(function($) {

	module("overlay: events");

})(jQuery);
