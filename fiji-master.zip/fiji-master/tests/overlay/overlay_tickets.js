/*
 * overlay_tickets.js
 */
(function($) {

module("overlay: tickets");

})(jQuery);
