/*
 * jaminari_tickets.js
 */
(function($) {

module("jaminari: tickets");

})(jQuery);
