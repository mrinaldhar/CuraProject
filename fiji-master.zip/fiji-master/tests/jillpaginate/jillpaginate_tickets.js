/*
 * jillpaginate_tickets.js
 */
(function($) {

module("jillpaginate: tickets");

})(jQuery);
