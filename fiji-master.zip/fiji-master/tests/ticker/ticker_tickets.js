/*
 * ticker_tickets.js
 */
(function($) {

module("ticker: tickets");

})(jQuery);
